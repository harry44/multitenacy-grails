package com.dogmasystems

class CompanyProfile {
    long id
     String companyName
    static constraints = {
    }
}
