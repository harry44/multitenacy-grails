package com.dogmasystems

class DatabaseConfiguration {
    String dataSourceName
    Map configuration
    static constraints = {
    }
}
