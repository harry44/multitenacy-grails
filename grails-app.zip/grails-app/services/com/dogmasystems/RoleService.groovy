package com.dogmasystems

import grails.gorm.transactions.Transactional

@Transactional
class RoleService {

    def saveRole() {

    }
}
