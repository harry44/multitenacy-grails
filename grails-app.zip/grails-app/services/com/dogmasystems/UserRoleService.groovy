package com.dogmasystems

import grails.gorm.transactions.Transactional

@Transactional
class UserRoleService {


}
